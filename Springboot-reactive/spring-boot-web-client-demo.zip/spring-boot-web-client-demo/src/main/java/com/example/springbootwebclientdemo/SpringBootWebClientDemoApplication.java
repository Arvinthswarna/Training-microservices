package com.example.springbootwebclientdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebClientDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebClientDemoApplication.class, args);
	}

}
