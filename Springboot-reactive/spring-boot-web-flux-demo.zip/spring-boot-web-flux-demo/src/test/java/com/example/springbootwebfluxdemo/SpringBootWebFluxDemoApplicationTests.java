package com.example.springbootwebfluxdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebFluxDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
