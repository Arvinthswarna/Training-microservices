package com.example.feignc2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeignC2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
