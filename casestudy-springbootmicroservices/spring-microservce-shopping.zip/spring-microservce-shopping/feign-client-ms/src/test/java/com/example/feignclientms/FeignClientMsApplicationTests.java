package com.example.feignclientms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeignClientMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
